interface a
{
int num=10;
void display();
int sub(int no);
}

interface c extends a
{
}

class b
{
int add()
{
return 10+10;
}
}

class exp_interface extends b implements c
{
public static void main(String [] args)
{
exp_interface b=new exp_interface();

System.out.println("The number returned by the add method of class b is "+b.add());

b.display();

int ans =b.sub(10);

System.out.println(ans);
}

public void display()
{
System.out.println("Overridden display method of interface");

System.out.println(num);

}
public int sub(int c)
{

System.out.println("Overridden sub method of interface");

return c-5;
}

}
