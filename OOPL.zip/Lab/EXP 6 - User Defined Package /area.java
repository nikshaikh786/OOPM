package areacalc;

public class area
{
public static void main(String [] args)
{

}

public int areaRect(int length,int breadth)
{
return length*breadth;
}

public int areaSquare(int side)
{
return side*side;
}

public float areaTriangle(int base,int height)
{
return 0.5f*base*height;
}

}
