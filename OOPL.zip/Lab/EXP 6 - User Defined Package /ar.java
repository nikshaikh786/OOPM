import areacalc.area;
import areacalc.perimeter;

//import areacalc.*;
class ar
{
public static void main(String [] args)
{
area a=new area();
perimeter p=new perimeter();
System.out.println("area is "+a.areaRect(4,5));
System.out.println("area is "+a.areaSquare(5));

System.out.println("perimeter is "+p.perirect(4,5));
System.out.println("perimeter is "+p.perisquare(5));


}

}
