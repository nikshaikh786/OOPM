package areacalc;
//this statement indicates the name of the package into which we want to include our class

public class perimeter
{

public static void main(String [] args)
{
}

public int perisquare(int side)
{
return 4*side;
}


public int perirect(int length,int breadth)
{
return 2*(length+breadth);
}


public float pericircle(float radius)
{
return 2*3.14f*radius;
}

}
