class dowhile
{
public static void main(String [] args)
{

int num=5;
int c=1;
int j=0;
do
{
j=j+num;
System.out.println(num+"X"+c+"="+j);
c++;

}
while(j<5*10);

}

}
