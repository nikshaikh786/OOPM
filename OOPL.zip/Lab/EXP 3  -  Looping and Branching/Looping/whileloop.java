class whileloop
{
public static void main(String [] args)
{

int i=0;
int c=1;
int num=7;

while(i<7*10)
{
i=i+num;
System.out.println(num+"X"+c+"="+i);
c++;
}


}

}
