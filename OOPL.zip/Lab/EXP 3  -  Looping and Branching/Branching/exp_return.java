class exp_return
{
public static void main(String [] args)
{
exp_return e=new exp_return();
int ans=e.add(9,12);
System.out.println("The answer of addition is "+ans);

}

int add(int a,int b)
{
int c=a+b;
return c;
}

}
